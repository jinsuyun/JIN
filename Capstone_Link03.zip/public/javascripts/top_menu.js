/*$(document).ready(function () {
        $(".nav navbar-nav").click(function(req,res){    
            $(".nav navbar-nav").append("<li class='active'>");
        });
});*/