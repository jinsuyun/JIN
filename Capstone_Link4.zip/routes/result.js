module.exports = {
    "OK": 1,
    "Fail": 2
}
